abstract class StatesApp{}
class StateAppInit extends StatesApp{}