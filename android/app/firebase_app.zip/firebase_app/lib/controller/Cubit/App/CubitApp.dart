
import 'package:firebase_app/controller/Cubit/App/StatesApp.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
class CubitApp extends Cubit<StatesApp>
{
  CubitApp() : super(StateAppInit());


}