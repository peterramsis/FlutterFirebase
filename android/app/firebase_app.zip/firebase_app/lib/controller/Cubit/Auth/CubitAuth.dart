import 'package:firebase_app/Model/User.dart';
import 'package:firebase_app/controller/Cubit/Auth/StatesAuth.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class CubitAuth extends Cubit<StatesAuth>{
  CubitAuth() : super(StatesAppInit());

  static CubitAuth get(context) => BlocProvider.of(context);
  TextEditingController email = TextEditingController();
  TextEditingController password = TextEditingController();
  TextEditingController address = TextEditingController();
  TextEditingController phone = TextEditingController();
  TextEditingController name = TextEditingController();

  var keyLogin = GlobalKey<FormState>();
  var keyRegister = GlobalKey<FormState>();

  UserModel? user;

  register() async{

    // emit(StatesRegisterLoading());
    // if(keyRegister.currentState!.validate()){
    //  print("click");
    //
    //   try{
    //
    //
    //
    //   }on FirebaseException catch(e){
    //     print(e.message);
    //     emit(StatesRegisterError(e.message.toString()));
    //   }

    user = UserModel(name.text, address.text, phone.text, "fggghhggg", email.text);

    var docRef = FirebaseFirestore.instance.collection('users');

    await docRef.doc("1234568903456").set({
      "name" : "Peter"
    }).then((value){
      print("click");
    }).catchError((err)=> print(err.toString()));

    // print(user!.toMap());
    //
    // //print(user!.toMap());

    // }

  }


  login({required String email , required String password}) async{

    if(keyLogin.currentState!.validate()){
      try{
        var result =   await FirebaseAuth.instance.signInWithEmailAndPassword(email: email, password: password);
         print("click");
      }on FirebaseAuthException catch(e)
      {
        print(e);
        emit(StatesLoginError(e.message.toString()));
      }

    }

  }

}